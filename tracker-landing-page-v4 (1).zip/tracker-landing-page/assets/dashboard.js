// Stargroup Tracker Link — dashboard logic
(function () {
    var BOOT = window.SG_BOOT || {};
    var apiUrl = BOOT.api || 'api.php';
    var POLL_MS = 6000;

    var $  = function (s, r) { return (r || document).querySelector(s); };
    var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

    function fmt(n) {
        n = Number(n) || 0;
        if (n >= 1_000_000) return (n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1) + 'M';
        if (n >= 1_000)     return (n / 1_000).toFixed(n >= 10_000 ? 0 : 1) + 'K';
        return String(n);
    }

    function timeAgo(iso) {
        if (!iso) return 'Belum ada aktivitas';
        var d = new Date(iso.replace(' ', 'T') + 'Z');
        if (isNaN(d.getTime())) return iso;
        var s = Math.max(0, Math.floor((Date.now() - d.getTime()) / 1000));
        if (s < 60)     return s + ' detik lalu';
        if (s < 3600)   return Math.floor(s / 60) + ' menit lalu';
        if (s < 86400)  return Math.floor(s / 3600) + ' jam lalu';
        return Math.floor(s / 86400) + ' hari lalu';
    }

    function flash(msg) {
        var el = document.createElement('div');
        el.className = 'flash';
        el.textContent = msg;
        document.body.appendChild(el);
        setTimeout(function () { el.remove(); }, 2000);
    }

    function setText(el, val) { if (el) el.textContent = val; }

    function tween(el, target) {
        if (!el) return;
        var from = parseFloat((el.dataset.raw || '0').toString()) || 0;
        var to   = Number(target) || 0;
        if (from === to) { el.textContent = fmt(to); el.dataset.raw = String(to); return; }
        var dur = 600, start = performance.now();
        function step(t) {
            var p = Math.min(1, (t - start) / dur);
            var eased = 1 - Math.pow(1 - p, 3);
            var v = from + (to - from) * eased;
            el.textContent = fmt(Math.round(v));
            if (p < 1) requestAnimationFrame(step);
            else      el.dataset.raw = String(to);
        }
        requestAnimationFrame(step);
    }

    function paint(data) {
        var trackers = data.trackers || [];
        var totals   = data.totals   || {};

        tween($('#m-visits'), totals.visits || 0);
        tween($('#m-ctas'),   totals.ctas   || 0);
        tween($('#m-dups'),   totals.duplicates || 0);
        setText($('#m-visits-today'), fmt(totals.visits_today || 0));
        setText($('#m-ctas-today'),   fmt(totals.ctas_today   || 0));
        var conv = totals.conversion || 0;
        setText($('#m-conv'), conv + '%');

        var active = 0;
        var maxV = 1;
        trackers.forEach(function (t) { maxV = Math.max(maxV, t.visits, t.ctas); });

        trackers.forEach(function (t) {
            var card = document.querySelector('.card[data-id="' + t.id + '"]');
            if (!card) return;
            tween($('[data-visits]',     card), t.visits);
            tween($('[data-ctas]',       card), t.ctas);
            tween($('[data-duplicates]', card), t.duplicates);
            setText($('[data-visits-today]', card), fmt(t.visits_today));
            setText($('[data-ctas-today]',   card), fmt(t.ctas_today));
            var c = (t.visits > 0) ? Math.round((t.ctas / t.visits) * 1000) / 10 : 0;
            setText($('[data-conv]', card), c + '%');
            setText($('[data-last]', card), 'Aktivitas: ' + timeAgo(t.last_event));
            $('.card-label', card).textContent = t.label;
            card.dataset.url = t.url || '';

            var bar = $('[data-bar]', card);
            if (bar) bar.style.width = Math.min(100, Math.round((t.visits / maxV) * 100)) + '%';

            if ((t.visits + t.ctas) > 0) active++;
        });

        setText($('#m-active'), active);
        setText($('#last-updated'), 'Terakhir diperbarui: ' + (data.now || ''));
    }

    function fetchSummary() {
        return fetch(apiUrl + '?action=summary', { credentials: 'same-origin', cache: 'no-store' })
            .then(function (r) { if (r.status === 401) { location.href = 'index.php'; return null; } return r.json(); })
            .then(function (j) { if (!j) return; if (j.ok) paint(j); })
            .catch(function () {});
    }

    /* ===== Modals ===== */
    function openModal(id) {
        var m = document.getElementById(id);
        if (m) m.hidden = false;
    }
    function closeModal(m) {
        if (typeof m === 'string') m = document.getElementById(m);
        if (m) m.hidden = true;
    }
    document.addEventListener('click', function (e) {
        if (e.target.matches('[data-close], .modal[data-close]')) {
            var m = e.target.closest('.modal');
            if (m) closeModal(m);
        }
    });
    document.querySelectorAll('.modal').forEach(function (m) {
        m.addEventListener('click', function (e) { if (e.target === m) closeModal(m); });
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') document.querySelectorAll('.modal:not([hidden])').forEach(closeModal);
    });

    /* ===== Card actions ===== */
    document.querySelectorAll('.card').forEach(function (card) {
        var id = card.dataset.id;

        $('[data-snippet]', card).addEventListener('click', function () {
            var label = $('.card-label', card).textContent.trim();
            var url   = (BOOT.base || '') + '/t.php?id=' + encodeURIComponent(id);
            var snippet = '<script src="' + url + '" async></' + 'script>';
            $('#snippetTitle').textContent = 'Embed Code — ' + label;
            $('#snippetCode').textContent = snippet;
            $('#copySnippet').onclick = function () {
                var ok = false;
                try {
                    if (navigator.clipboard) { navigator.clipboard.writeText(snippet); ok = true; }
                } catch (e) {}
                if (!ok) {
                    var ta = document.createElement('textarea');
                    ta.value = snippet; document.body.appendChild(ta);
                    ta.select(); document.execCommand('copy'); ta.remove();
                }
                flash('Snippet disalin');
            };
            openModal('snippetModal');
        });

        $('[data-edit]', card).addEventListener('click', function () {
            $('#editId').value    = id;
            $('#editLabel').value = $('.card-label', card).textContent.trim();
            $('#editUrl').value   = card.dataset.url || '';
            openModal('editModal');
        });

        $('[data-detail]', card).addEventListener('click', function () {
            openDetail(id, $('.card-label', card).textContent.trim());
        });

        $('[data-reset]', card).addEventListener('click', function () {
            if (!confirm('Reset semua data tracker ini? Tidak bisa dibatalkan.')) return;
            var fd = new FormData();
            fd.append('csrf', BOOT.csrf);
            fd.append('id',   id);
            fetch(apiUrl + '?action=reset', { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function (r) { return r.json(); })
                .then(function (j) {
                    if (j.ok) { flash('Tracker direset'); fetchSummary(); }
                    else flash('Gagal reset');
                });
        });
    });

    /* ===== Edit form ===== */
    var ef = $('#editForm');
    if (ef) ef.addEventListener('submit', function (e) {
        e.preventDefault();
        var fd = new FormData(ef);
        fetch(apiUrl + '?action=rename', { method: 'POST', body: fd, credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (j) {
                if (j.ok) { flash('Tersimpan'); closeModal('editModal'); fetchSummary(); }
                else { flash('Gagal menyimpan'); }
            });
    });

    /* ===== Detail ===== */
    function openDetail(id, label) {
        $('#detailTitle').textContent = 'Detail — ' + label;
        $('#hourlyChart').innerHTML = '<div class="mini" style="color:#8a90a6">Memuat…</div>';
        $('#recentList').innerHTML  = '<div class="mini" style="color:#8a90a6">Memuat…</div>';
        openModal('detailModal');

        fetch(apiUrl + '?action=detail&id=' + encodeURIComponent(id), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (j) {
                if (!j.ok) return;
                var hourly = j.hourly || [];
                var max = 1;
                hourly.forEach(function (h) { max = Math.max(max, h.v + h.c); });
                var html = '';
                if (!hourly.length) html = '<div class="mini" style="color:#8a90a6">Belum ada aktivitas dalam 24 jam.</div>';
                hourly.forEach(function (h) {
                    var hv = Math.round((h.v / max) * 140);
                    var hc = Math.round((h.c / max) * 140);
                    var t = (h.h || '').slice(11, 13);
                    html += '<div class="h-col">' +
                        '<div class="h-bar"     style="height:' + hv + 'px" title="Visits: ' + h.v + '"></div>' +
                        '<div class="h-bar cta" style="height:' + hc + 'px" title="CTA: '   + h.c + '"></div>' +
                        '<div class="h-time">' + t + '</div></div>';
                });
                $('#hourlyChart').innerHTML = html;

                var recent = j.recent || [];
                var rh = '';
                if (!recent.length) rh = '<div class="mini" style="color:#8a90a6">Belum ada event.</div>';
                recent.forEach(function (e) {
                    var pill = e.type === 'visit' ? '<span class="pill visit">Visit</span>' : '<span class="pill cta">CTA</span>';
                    var meta = '';
                    try { var m = JSON.parse(e.meta || '{}'); if (m.l) meta = ' · ' + m.l; } catch (x) {}
                    rh += '<div class="recent-row">' + pill +
                        '<span>' + escapeHtml((e.ref || meta || '').toString().slice(0, 80)) + '</span>' +
                        '<span class="ts">' + timeAgo(e.created_at) + '</span></div>';
                });
                $('#recentList').innerHTML = rh;
            });
    }

    function escapeHtml(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
        });
    }

    fetchSummary();
    setInterval(fetchSummary, POLL_MS);
})();
